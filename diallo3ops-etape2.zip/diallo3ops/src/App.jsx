import { useEffect, useState } from 'react';
import { OPERATEURS, formaterFCFA } from './domain/ledger.js';
import { soldeOperateur, demanderStockagePersistant } from './db/repository.js';
import LockScreen from './components/LockScreen.jsx';

// Écran provisoire : soldes des trois opérateurs, derrière le code PIN.
export default function App() {
  const [deverrouille, setDeverrouille] = useState(false);
  const [soldes, setSoldes] = useState(null);
  const [erreur, setErreur] = useState('');

  useEffect(() => {
    if (!deverrouille) return;
    demanderStockagePersistant();
    Promise.all(Object.keys(OPERATEURS).map(async (id) => [id, await soldeOperateur(id)]))
      .then((entrees) => setSoldes(Object.fromEntries(entrees)))
      .catch((e) => setErreur(e.message));
  }, [deverrouille]);

  if (!deverrouille) return <LockScreen onDeverrouille={() => setDeverrouille(true)} />;

  return (
    <main style={{ fontFamily: 'system-ui, sans-serif', padding: 16, maxWidth: 480, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22 }}>DIALLO 3 OPÉRATEURS</h1>
      <p style={{ color: '#555' }}>Étape 2 : code PIN et mode hors ligne. Écrans à venir.</p>
      {erreur && <p style={{ color: '#b91c1c' }}>{erreur}</p>}
      {Object.entries(OPERATEURS).map(([id, nom]) => (
        <section key={id} style={{ background: '#f0fdfa', borderRadius: 16, padding: 16, margin: '12px 0' }}>
          <strong>{nom}</strong>
          <div style={{ fontSize: 24 }}>{soldes ? formaterFCFA(soldes[id]) : '…'}</div>
        </section>
      ))}
    </main>
  );
}
